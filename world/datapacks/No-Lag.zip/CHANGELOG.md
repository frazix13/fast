### Changed

- updated to Minecraft 1.20
- removed glow squids from farm animals -> now affected by lag clears
- improved performance of lag clears

### Fixed

- broken automatic updates between v3.0.3 - v3.1.1
